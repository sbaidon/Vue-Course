var mixin = {
  filters: {
    capitalize() {
      return value.toUpperCase();
    }
  }
}

export default mixin;